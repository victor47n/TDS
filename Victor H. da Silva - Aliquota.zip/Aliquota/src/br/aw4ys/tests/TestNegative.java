package br.aw4ys.tests;
import junit.framework.TestCase;
import org.junit.jupiter.api.Test;

import br.aw4ys.view.AliquotaIR;

public class TestNegative extends TestCase {

	@Test
	public void testExecutaAliquotaIR ( ) { 
		
		AliquotaIR a = new AliquotaIR();
		double AliquotaRetorno1 = a.RetornaAliquota(-1);
		assertEquals(0.0, AliquotaRetorno1);

	}

}
