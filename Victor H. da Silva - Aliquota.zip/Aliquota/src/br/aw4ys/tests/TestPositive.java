package br.aw4ys.tests;
import org.junit.jupiter.api.Test;

import br.aw4ys.view.AliquotaIR;
import junit.framework.TestCase;

public class TestPositive extends TestCase {

		@Test
		public void testExecutaAliquotaIR ( ) { 
			
			AliquotaIR a = new AliquotaIR();
			double AliquotaRetorno1 = a.RetornaAliquota(22847.76);
			assertEquals(0.0, AliquotaRetorno1);
			
			double AliquotaRetorno2 = a.RetornaAliquota(22847.77);
	        assertEquals(7.5, AliquotaRetorno2);
			
			double AliquotaRetorno3 = a.RetornaAliquota(33919.80);
	        assertEquals(7.5, AliquotaRetorno3);
	        
	        double AliquotaRetorno4 = a.RetornaAliquota(33919.81);
	        assertEquals(15.0, AliquotaRetorno4);
	        
	        double AliquotaRetorno5 = a.RetornaAliquota(45012.60);
	        assertEquals(15.0, AliquotaRetorno5);
	        
	        double AliquotaRetorno6 = a.RetornaAliquota(45012.61);
	        assertEquals(22.5, AliquotaRetorno6);
	        
	        double AliquotaRetorno7 = a.RetornaAliquota(55976.16);
	        assertEquals(22.5, AliquotaRetorno7);
	        
	        double AliquotaRetorno8 = a.RetornaAliquota(55976.17);
	        assertEquals(27.5, AliquotaRetorno8);

		}
}
