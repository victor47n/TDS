package br.aw4ys.view;

public class AliquotaIR {

	public double RetornaAliquota(double rendimento) {
	if (rendimento >= 0 && rendimento < 22847.77) {			
		return 0;
	}
	else if (rendimento > 22847.76 && rendimento < 33919.81) {
		return 7.5;
		
	}
	else if (rendimento > 33919.8 && rendimento < 45012.61) {
		return 15;
		
	}
	else if (rendimento > 45012.60 && rendimento < 55976.17) {
		return 22.5;
		
	}
	
	else if (rendimento > 55976.16) {
		return 27.5;
		
	}
	return 0;
	
	}

}
